export function getRandomInt(max) {
  // returns 0 .. max-1
  return Math.floor(Math.random() * max);
}
